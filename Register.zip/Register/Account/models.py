from django.db import models

# Create your models here.
class FirstTable(models.Model):
    name = models.CharField(max_length=100)
    age = models.CharField(max_length=4)